package com.example.l2t2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }


    private val questions = arrayListOf<Questions>()
    private val questionAdapter = QuestionAdapter(questions)

    private fun initViews() {
        // Initialize the recycler view with a linear layout manager, adapter

    }

}

}
