package com.example.l2t2

data class Questions(
    var questionText: String,
    var QuestionTruth: Boolean
)
